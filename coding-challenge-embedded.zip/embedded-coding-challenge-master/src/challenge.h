#pragma once

#include <stdint.h>

// needs to be implemented for the challenge
void receive_ISR(uint8_t data);

// needs to be implemented for the challenge
void challenge_init();

// needs to be implemented for the challenge
void challenge_run();

